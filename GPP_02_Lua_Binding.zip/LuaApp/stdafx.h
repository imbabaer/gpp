﻿#pragma once

#include <errno.h>
#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <windows.h>

#include <lua.hpp>
