--[[
	GEP_00_Lua.lua
	
	For documentation see: http://www.lua.org/manual/5.2/manual.html#3
]]


