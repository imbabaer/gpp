print("Executing pong.lua")

--Camera
Cam:setPosition(Vec3(-300,0,0))

--PhysicsDebugView
PhysicsSystem:setDebugDrawingEnabled(true)

