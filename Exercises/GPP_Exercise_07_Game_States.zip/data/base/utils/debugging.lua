
function debugBreak(message)
	Scripting:_debugBreak(message or "[LUA DEBUG BREAK]")
end
