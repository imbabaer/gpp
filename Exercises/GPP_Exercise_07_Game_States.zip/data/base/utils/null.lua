
null = { __ptr = 0 }
