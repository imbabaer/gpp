
print("Initializing from lua...")

Scripting:registerScript("state_machine.lua")

print("Finished initializing from lua.")
