logMessage("Initializing state_machine.lua ...")

-- Physics World
do
	local cinfo = WorldCInfo()
	cinfo.gravity = Vec3(0, 0, 0)
	cinfo.worldSize = 2000.0
	local world = PhysicsFactory:createWorld(cinfo)
	PhysicsSystem:setWorld(world)
end

-- Camera
cam = GameObjectManager:createGameObject("cam")
cam.cc = cam:createCameraComponent()
cam.cc:setPosition(Vec3(0.0, -300.0, 0.0))
cam.cc:lookAt(Vec3(0.0, 0.0, 0.0))
cam.cc:setState(ComponentState.Active)


logMessage("Finished initializing state_machine.lua")
