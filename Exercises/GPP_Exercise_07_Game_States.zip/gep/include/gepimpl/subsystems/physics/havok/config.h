#pragma once

// Havok specific configuration
#define HK_CONFIG_SIMD HK_CONFIG_SIMD_ENABLED

// Internal settings concerning havok.

