
print("Initializing from lua...")

Scripting:registerScript("asteroids_update.lua")
Scripting:registerScript("asteroids_initialize.lua")

print("Finished initializing from lua.")
