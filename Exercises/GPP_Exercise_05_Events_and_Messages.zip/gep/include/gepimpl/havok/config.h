
#ifdef _DEBUG
#define GEP_USE_HK_VISUAL_DEBUGGER
#endif // _DEBUG

#include "gepimpl/subsystems/physics/havok/config.h"
#include "gepimpl/subsystems/animation/havok/config.h"
