// Except for stdafx.h, this file includes all files that have to be included exactly once in this project.

#include "stdafx.h"
#include "gep/memory/newdelete.inl"
