
settings = {
	video = {
		screenResolution = Vec2i(1280, 720),
		vsyncEnabled = true,
	},
}

Settings:load(settings)
