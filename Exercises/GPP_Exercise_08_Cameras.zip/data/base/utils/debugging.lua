
function debugBreak(message)
	Scripting:_debugBreak(message or "")
end
