
print("Initializing from lua...")

-- Scripting:registerScript("state_machine.lua")

Scripting:registerScript("camera_prototype/camera_prototype.lua")

print("Finished initializing from lua.")
