#include "stdafx.h"

#define NUM_KEYS (VK_OEM_CLEAR + 1)
std::vector<bool> KeysDown;
std::vector<bool> KeysPressed;
DWORD sleepTime = 100;
HANDLE hConsole;
COORD cursorHomePosition = { 0, 0 };
enum { EXIT_GAME = 0, CONTINUE_GAME };

int lua_CFunction_isKeyDown(lua_State* L)
{
	// TODO implement lua_CFunction_isKeyDown
	
	KeysDown;
	return 1;
}

int lua_CFunction_wasKeyPressed(lua_State* L)
{
	// TODO implement lua_CFunction_wasKeyPressed

	KeysPressed;
	return 1;
}

int lua_CFunction_setSleepTime(lua_State* L)
{
	// TODO implement lua_CFunction_setSleepTime

	::sleepTime;
	return 0;
}

int main(int argc, char* argv[])
{
	if (argc < 2)
	{
		printf("-------------------- LuaCmdGame.exe --------------------\n");
		printf("Please specify a .lua file to be processed, for example:\n");
		printf("  LuaCmdGame.exe EmptyCmdGame.lua\n");
		printf("--------------------------------------------------------\n");
		system("pause");
		return 0;
	}

	// TODO create a new Lua state

	// TODO open all Lua standard libraries

	// TODO load and execute the Lua file
	const char* filename = argv[1];

	// initialize the keyboard states
	KeysDown.resize(NUM_KEYS);
	KeysPressed.resize(NUM_KEYS);
	for (int key = 1; key < NUM_KEYS; ++key)
	{
		KeysDown[key] = false;
		KeysPressed[key] = false;
	}

	// TODO register all lua_CFunctions
	lua_CFunction_isKeyDown;
	lua_CFunction_wasKeyPressed;
	lua_CFunction_setSleepTime;

	// TODO register global exit codes
	EXIT_GAME;
	CONTINUE_GAME;

	// TODO call the Lua function initialize()

	// get the console handle
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	system("cls");

	// game loop
	while (!KeysDown[VK_ESCAPE])
	{
		// read keyboard input
		for (int key = 1; key < NUM_KEYS; ++key)
		{
			KeysPressed[key] = false;
			bool keyDown = GetAsyncKeyState(key) != FALSE;
			if (KeysDown[key] != keyDown)
				KeysPressed[key] = true;
			KeysDown[key] = keyDown;
		}

		// TODO call the Lua function update()

		// TODO get the return value from update()
		int returnValue = CONTINUE_GAME;
		if (returnValue == EXIT_GAME)
			break;

		// reset cursor to 0,0
		SetConsoleCursorPosition(hConsole, cursorHomePosition);

		// TODO call the Lua function draw()

		// sleep for a few milliseconds
		Sleep(sleepTime);
	}

	// TODO close the Lua state

	return 0;
}
