
--[[
	API overview

	-- set the sleep time
	-- milliseconds: the sleep time in milliseconds
	setSleepTime(milliseconds)

	-- checks if a key is down
	-- VK_CODE: virtual-key code => http://msdn.microsoft.com/en-us/library/windows/desktop/dd375731%28v=vs.85%29.aspx
	-- returns true if the key is currently down, otherwise false
	bool isKeyDown( VK_CODE )

	-- checks if a key was just pressed
	-- VK_CODE: virtual-key code => http://msdn.microsoft.com/en-us/library/windows/desktop/dd375731%28v=vs.85%29.aspx
	-- returns true if the key was just pressed, otherwise false
	bool wasKeyPressed( VK_CODE )
]]

-- virtual-key codes from http://msdn.microsoft.com/en-us/library/windows/desktop/dd375731%28v=vs.85%29.aspx
VK_LEFT		= 0x25
VK_RIGHT	= 0x27
VK_UP		= 0x26
VK_DOWN		= 0x28
VK_SPACE	= 0x20
VK_RETURN	= 0x0D
VK_Q		= 0x51

-- is called once upon start-up
function initialize()

	-- TODO put your initialization code here

	setSleepTime(100)
end

-- is called once at the beginning of every frame
-- returns either EXIT_GAME or CONTINUE_GAME to continue or exit the game, respectively.
function update()

	-- TODO put your update code here

	if (wasKeyPressed(VK_Q)) then
		return EXIT_GAME
	end
	return CONTINUE_GAME
end

-- is called once at the end of every frame
function draw()

	print("\n***** EmptyCmdGame.lua *****")	-- print automatically adds "\n"
	io.write("\npress q to quit\n")			-- io.write does not add an "\n"

	-- TODO put your drawing code here
end
