﻿#pragma once

#include <errno.h>
#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <windows.h>

extern "C"
{
	#include "lua.h"
	#include "lauxlib.h"
	#include "lualib.h"
}
