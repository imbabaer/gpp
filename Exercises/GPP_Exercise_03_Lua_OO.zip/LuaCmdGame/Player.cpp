#include "stdafx.h"
#include "Player.h"

Player* Player::s_pInstance = nullptr;

Player* Player::getInstance()
{
	if (s_pInstance == nullptr)
		s_pInstance = new Player;
	return s_pInstance;
}

void Player::destroy()
{
	delete(s_pInstance);
	s_pInstance = nullptr;
}

const char* Player::getName() const
{
	return m_name.c_str();
}

void Player::setName(const std::string& name)
{
	m_name = name;
}

Vec2 Player::getPosition() const
{
	return m_position;
}

void Player::setPosition(const Vec2& position)
{
	m_position = position;
}

void Player::lua_bind(lua_State* L)
{
	// TODO create a new meta table "PlayerMeta"
	// TODO set the field "__index" properly

	// TODO add the functions "getName", "setName", "getPosition", and "setPosition" to the meta table
	lua_CFunction_getName;		// "getName"
	lua_CFunction_setName;		// "setName"
	lua_CFunction_getPosition;	// "getPosition"
	lua_CFunction_setPosition;	// "setPosition"
	
	// TODO register a global player instance called "Player"
	// the player pointer can be obtained via "getInstance()"
}

int Player::lua_CFunction_getName(lua_State* L)
{
	// TODO create "Player* pSelf" from the stack
	// TODO push "pSelf->getName()" on the stack
	return 0;
}

int Player::lua_CFunction_setName(lua_State* L)
{
	// TODO create "Player* pSelf" from the stack
	// TODO get "const char* name" from the stack
	// TODO call "pSelf->setName(name)"
	return 0;
}

int Player::lua_CFunction_getPosition(lua_State* L)
{
	// TODO create "Player* pSelf" from the stack
	// TODO push "pSelf->getPosition()" on the stack
	return 0;
}

int Player::lua_CFunction_setPosition(lua_State* L)
{
	// TODO create "Player* pSelf" from the stack
	// TODO create and initialize "Vec2 position" from the stack
	// TODO call "pSelf->setPosition(position)"
	return 0;
}
