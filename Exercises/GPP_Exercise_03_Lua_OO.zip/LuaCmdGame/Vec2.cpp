#include "stdafx.h"
#include "Vec2.h"

Vec2::Vec2() : 
	m_x(0.f),
	m_y(0.f)
{
}

Vec2::Vec2(float x, float y) : 
	m_x(x),
	m_y(y)
{

}

float Vec2::length() const
{
	return (float)sqrt(m_x*m_x + m_y*m_y);
}

Vec2 Vec2::operator+(const Vec2& other) const
{
	Vec2 result;
	result.m_x = m_x + other.m_x;
	result.m_y = m_y + other.m_y;
	return result;
}

Vec2 Vec2::operator-(const Vec2& other) const
{
	Vec2 result;
	result.m_x = m_x - other.m_x;
	result.m_y = m_y - other.m_y;
	return result;
}

void Vec2::lua_bind(lua_State* L)
{
	// TODO create a new meta table "Vec2Meta"
	// TODO set the field "__index" properly

	// TODO add the functions "length", "__add", and "__sub" to the meta table
	lua_CFunction_length;	// "length"
	lua_CFunction_add;		// "__add"
	lua_CFunction_sub;		// "__sub"
	
	// TODO register a global function "Vec2" which serves as constructor
	lua_CFunction_Vec2;		// "Vec2"
}

int Vec2::lua_CFunction_Vec2(lua_State* L)
{
	// TODO create "Vec2 instance"
	// TODO initialite "instance"
	//	either from a table {x, y}
	//	or from two numbers x, y
	// TODO push "instance" on the stack
	return 0;
}

int Vec2::lua_CFunction_length(lua_State* L)
{
	// TODO create and initialize "Vec2 self" from the stack
	// TODO push "self.length()" on the stack
	return 0;
}

int Vec2::lua_CFunction_add(lua_State* L)
{
	// TODO create and initialize "Vec2 self" from the stack
	// TODO create and initialize "Vec2 other" from the stack
	// TODO calculate "Vec2 result = self + other"
	// TODO push "result" on the stack
	return 0;
}

int Vec2::lua_CFunction_sub(lua_State* L)
{
	// TODO create and initialize "Vec2 self" from the stack
	// TODO create and initialize "Vec2 other" from the stack
	// TODO calculate "Vec2 result = self - other"
	// TODO push "result" on the stack
	return 0;
}
