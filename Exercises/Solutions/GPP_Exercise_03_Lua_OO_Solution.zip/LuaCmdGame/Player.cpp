#include "stdafx.h"
#include "Player.h"

Player* Player::s_pInstance = nullptr;

Player* Player::getInstance()
{
	if (s_pInstance == nullptr)
		s_pInstance = new Player;
	return s_pInstance;
}

void Player::destroy()
{
	delete(s_pInstance);
	s_pInstance = nullptr;
}

const char* Player::getName() const
{
	return m_name.c_str();
}

void Player::setName(const std::string& name)
{
	m_name = name;
}

Vec2 Player::getPosition() const
{
	return m_position;
}

void Player::setPosition(const Vec2& position)
{
	m_position = position;
}

void Player::lua_bind(lua_State* L)
{
	luaL_newmetatable(L, "PlayerMeta");
	lua_pushvalue(L, -1);
	lua_setfield(L, -2, "__index");
	lua_pushcfunction(L, lua_CFunction_getName);
	lua_setfield(L, -2, "getName");
	lua_pushcfunction(L, lua_CFunction_setName);
	lua_setfield(L, -2, "setName");
	lua_pushcfunction(L, lua_CFunction_getPosition);
	lua_setfield(L, -2, "getPosition");
	lua_pushcfunction(L, lua_CFunction_setPosition);
	lua_setfield(L, -2, "setPosition");

	getInstance()->toLuaTable(L);
	lua_setglobal(L, "Player");
}

int Player::lua_CFunction_getName(lua_State* L)
{
	int n = lua_gettop(L);
	if (n != 1)
		luaL_error(L, "invalid number of parameters");
	Player* pSelf = Player::fromLuaTable(L);
	const char* name = pSelf->getName();
	lua_pushstring(L, name);
	return 1;
}

int Player::lua_CFunction_setName(lua_State* L)
{
	int n = lua_gettop(L);
	if (n != 2)
		luaL_error(L, "invalid number of parameters");
	Player* pSelf = Player::fromLuaTable(L);
	if (!lua_isstring(L, 1))
		luaL_error(L, "expected type string as parameter");
	const char* name = lua_tostring(L, 1);
	pSelf->setName(name);
	return 0;
}

int Player::lua_CFunction_getPosition(lua_State* L)
{
	int n = lua_gettop(L);
	if (n != 1)
		luaL_error(L, "invalid number of parameters");
	Player* pSelf = Player::fromLuaTable(L);
	Vec2 position = pSelf->getPosition();
	position.toLuaTable(L);
	return 1;
}

int Player::lua_CFunction_setPosition(lua_State* L)
{
	int n = lua_gettop(L);
	if (n < 1 || n > 3)
		luaL_error(L, "invalid number of parameters");
	Player* pSelf = Player::fromLuaTable(L);
	Vec2 position;
	position.fromLuaTable(L);
	pSelf->setPosition(position);
	return 0;
}

Player* Player::fromLuaTable(lua_State* L)
{
	Player* pSelf = nullptr;
	if (lua_istable(L, 1))
	{
		lua_getfield(L, 1, "__ptr");
		if (!lua_islightuserdata(L, -1))
			luaL_error(L, "expected type lightuserdata in field \"__ptr\"");
		pSelf = (Player*)lua_topointer(L, -1);
		lua_pop(L, 1);
		lua_remove(L, 1);
	}	
	return pSelf;
}

void Player::toLuaTable(lua_State* L)
{
	lua_newtable(L);
	lua_pushstring(L, "__ptr");
	lua_pushlightuserdata(L, this);
	lua_settable(L, -3);
	luaL_setmetatable(L, "PlayerMeta");
}
