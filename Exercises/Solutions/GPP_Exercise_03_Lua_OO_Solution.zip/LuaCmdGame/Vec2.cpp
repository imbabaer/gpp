#include "stdafx.h"
#include "Vec2.h"

Vec2::Vec2() : 
	m_x(0.f),
	m_y(0.f)
{
}

Vec2::Vec2(float x, float y) : 
	m_x(x),
	m_y(y)
{

}

float Vec2::length() const
{
	return (float)sqrt(m_x*m_x + m_y*m_y);
}

Vec2 Vec2::operator+(const Vec2& other) const
{
	Vec2 result;
	result.m_x = m_x + other.m_x;
	result.m_y = m_y + other.m_y;
	return result;
}

Vec2 Vec2::operator-(const Vec2& other) const
{
	Vec2 result;
	result.m_x = m_x - other.m_x;
	result.m_y = m_y - other.m_y;
	return result;
}

void Vec2::lua_bind(lua_State* L)
{
	luaL_newmetatable(L, "Vec2Meta");
	lua_pushvalue(L, -1);
	lua_setfield(L, -2, "__index");
	lua_pushcfunction(L, lua_CFunction_length);
	lua_setfield(L, -2, "length");
	lua_pushcfunction(L, lua_CFunction_add);
	lua_setfield(L, -2, "__add");
	lua_pushcfunction(L, lua_CFunction_sub);
	lua_setfield(L, -2, "__sub");

	lua_pushcfunction(L, lua_CFunction_Vec2);
	lua_setglobal(L, "Vec2");
}

int Vec2::lua_CFunction_Vec2(lua_State* L)
{
	int n = lua_gettop(L);
	if (n < 1 || n > 2)
		luaL_error(L, "invalid number of parameters");
	Vec2 instance;
	instance.fromLuaTable(L);
	instance.toLuaTable(L);
	return 1;
}

int Vec2::lua_CFunction_length(lua_State* L)
{
	int n = lua_gettop(L);
	if (n != 1)
		luaL_error(L, "invalid number of parameters");
	Vec2 self;
	self.fromLuaTable(L);
	float length = self.length();
	lua_pushnumber(L, (lua_Number)length);
	return 1;
}

int Vec2::lua_CFunction_add(lua_State* L)
{
	int n = lua_gettop(L);
	if (n < 2 || n > 3)
		luaL_error(L, "invalid number of parameters");
	Vec2 self;
	self.fromLuaTable(L);
	Vec2 other;
	other.fromLuaTable(L);
	Vec2 result = self + other;
	result.toLuaTable(L);
	return 1;
}

int Vec2::lua_CFunction_sub(lua_State* L)
{
	int n = lua_gettop(L);
	if (n < 2 || n > 3)
		luaL_error(L, "invalid number of parameters");
	Vec2 self;
	self.fromLuaTable(L);
	Vec2 other;
	other.fromLuaTable(L);
	Vec2 result = self - other;
	result.toLuaTable(L);
	return 1;
}

void Vec2::fromLuaTable(lua_State* L)
{
	if (lua_istable(L, 1))
	{
		lua_getfield(L, 1, "x");
		if (!lua_isnumber(L, -1))
			luaL_error(L, "expected type number in field \"x\"");
		m_x = (float)lua_tonumber(L, -1);
		lua_pop(L, 1);
		lua_getfield(L, 1, "y");
		if (!lua_isnumber(L, -1))
			luaL_error(L, "expected type number in field \"y\"");
		m_y = (float)lua_tonumber(L, -1);
		lua_pop(L, 1);
		lua_remove(L, 1);
	}
	else if (lua_isnumber(L, 1) && lua_isnumber(L, 2))
	{
		m_x = (float)lua_tonumber(L, 1);
		m_y = (float)lua_tonumber(L, 2);
		lua_remove(L, 2);
	}
	else
	{
		luaL_error(L, "invalid paramaters");
	}
}

void Vec2::toLuaTable(lua_State* L)
{
	lua_newtable(L);
	lua_pushstring(L, "x");
	lua_pushnumber(L, m_x);
	lua_settable(L, -3);
	lua_pushstring(L, "y");
	lua_pushnumber(L, m_y);
	lua_settable(L, -3);
	luaL_setmetatable(L, "Vec2Meta");
}
