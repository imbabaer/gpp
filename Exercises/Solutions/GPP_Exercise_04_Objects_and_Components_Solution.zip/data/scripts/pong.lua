print("Executing pong.lua")

--Camera
Cam:setPosition(Vec3(-300,0,0))

--PhysicsDebugView
PhysicsSystem:setDebugDrawingEnabled(true)

local playerSpeed = 200.0
local playerRotSpeed = 2.5
local maxLinearVelocity = 350

function createPlayer(guid)
	local go = GameObjectManager:createGameObject(tostring(guid))
--	local renderComponent = go:createRenderComponent()
--	renderComponent:setPath("data/models/ball.thModel")
	local physicsComponent = go:createPhysicsComponent()
	local cinfo = RigidBodyCInfo()
	cinfo.shape = PhysicsFactory:createBox(7.5, 7.5, 25.0)

	cinfo.motionType = MotionType.MotionKeyframed
	cinfo.restitution = 1.0
	physicsComponent:createRigidBody(cinfo)
	local scriptComponent = go:createScriptComponent()
	return go
end

function createBall()
	local go = GameObjectManager:createGameObject("ball")
	local physicsComponent = go:createPhysicsComponent()
	local cinfo = RigidBodyCInfo()
	cinfo.shape = PhysicsFactory:createSphere(7,5)
	cinfo.motionType = MotionType.Dynamic
	cinfo.mass = 1.0
	cinfo.friction = 0.5
	cinfo.restitution = 1.0
	cinfo.linearVelocity = Vec3(0, -90, 25)
	cinfo.angularVelocity = Vec3(0, 15,0)
	cinfo.maxLinearVelocity = maxLinearVelocity
	physicsComponent:createRigidBody(cinfo)
	local scriptComponent = go:createScriptComponent()
	return go
end

function createBorder()
	--TOP
	local go = GameObjectManager:createGameObject("borderTop")
	local physicsComponent = go:createPhysicsComponent()
	local cinfo = RigidBodyCInfo()
	cinfo.shape = PhysicsFactory:createBox(1.0,500.0,1.0)
	cinfo.motionType = MotionType.Fixed
	cinfo.friction = 0.0
	cinfo.angularDamping = 0.0
	cinfo.restitution = 1.0
	physicsComponent:createRigidBody(cinfo)
	go:setPosition(Vec3(0.0,0.0,125.0))
	--BOTTOM
	local go = GameObjectManager:createGameObject("borderBottom")
	local physicsComponent = go:createPhysicsComponent()
	local cinfo = RigidBodyCInfo()
	cinfo.shape = PhysicsFactory:createBox(1.0,500.0,1.0)
	cinfo.motionType = MotionType.Fixed
	cinfo.friction = 0.0
	cinfo.angularDamping = 0.0
	cinfo.restitution = 1.0
	physicsComponent:createRigidBody(cinfo)
	go:setPosition(Vec3(0.0,0.0,-125.0))
end


function p1_update(gameObjectName, elapsedMilliseconds)
	local pos = p1:getPosition()
	local vel = Vec3(0.0, 0.0, 0.0)
	local angVel = Vec3(0.0, 0.0, 0.0)

	--Move Up
	if (InputHandler:isPressed(Key.W) and pos.z < 105) then vel.z = playerSpeed end
	--Move Down
	if (InputHandler:isPressed(Key.S) and pos.z > -105) then vel.z = -playerSpeed end
	--Move Left
	if (InputHandler:isPressed(Key.A) and pos.y < 295) then vel.y = playerSpeed end
	--Move Right
	if (InputHandler:isPressed(Key.D) and pos.y > 100) then vel.y = -playerSpeed end
	--Rotate Left
	if InputHandler:isPressed(Key.E) then angVel.x = playerRotSpeed end
	--Rotate Right
	if InputHandler:isPressed(Key.Q) then angVel.x =  -playerRotSpeed end

	p1:getPhysicsComponent():getRigidBody():setLinearVelocity(vel)
	p1:getPhysicsComponent():getRigidBody():setAngularVelocity(angVel)
end

function p2_update(gameObjectName, elapsedMilliseconds)
	local pos = p2:getPosition()
	local vel = Vec3(0.0, 0.0, 0.0)
	local angVel = Vec3(0.0, 0.0, 0.0)

	--Move Up
	if (InputHandler:isPressed(Key.Up) and pos.z < 105) then vel.z = playerSpeed end
	--Move Down
	if (InputHandler:isPressed(Key.Down) and pos.z > -105) then vel.z = -playerSpeed end
	--Move Left
	if (InputHandler:isPressed(Key.Left) and pos.y < -100) then vel.y = playerSpeed end
	--Move Right
	if (InputHandler:isPressed(Key.Right) and pos.y > -295) then vel.y = -playerSpeed end
	--Rotate Left
	if InputHandler:isPressed(Key.O) then angVel.x = playerRotSpeed end
	--Rotate Right
	if InputHandler:isPressed(Key.P) then angVel.x = -playerRotSpeed end

	p2:getPhysicsComponent():getRigidBody():setLinearVelocity(vel)
	p2:getPhysicsComponent():getRigidBody():setAngularVelocity(angVel)
end

function ball_update(gameObjectName, elapsedMilliseconds)
	--prevent the ball from leaving the 2 dimensional world
	local vel = ball:getPhysicsComponent():getRigidBody():getLinearVelocity()
	ball:getPhysicsComponent():getRigidBody():setLinearVelocity(Vec3(0, vel.y, vel.z))
	local pos = ball:getPosition()
	ball:setPosition(Vec3(0.0, pos.y, pos.z))

	--player two misses
	if pos.y < -300 then
		p1.score = p1.score + 1
		ball:setPosition(Vec3(0, 0, 0))
		ball:getPhysicsComponent():getRigidBody():setLinearVelocity(Vec3(0, 120, math.random(0,50)))
	end

	--player one misses
	if pos.y > 300 then
		p2.score = p2.score + 1
		ball:setPosition(Vec3(0, 0, 0))
		ball:getPhysicsComponent():getRigidBody():setLinearVelocity(Vec3(0, -120, math.random(0,50)))
	end

	DebugRenderer:printText(Vec2(-0.9, 0.9), "Player 1 Score: " .. p1.score)
	DebugRenderer:printText(Vec2(0.7, 0.9), "Player 2 Score: " .. p2.score)
	DebugRenderer:printText(Vec2(-0.2, 0.9), "Ball: " .. string.format("%2.2f", pos.x) .. ", " .. string.format("%2.2f", pos.y) .. ", " .. string.format("%2.2f", pos.z))
end

--Player 1

p1 = createPlayer("player1")
p1:setPosition(Vec3(0,250,0))
p1:getScriptComponent():setUpdateFunction("p1_update")
p1.score = 0

--player 2

p2 = createPlayer("player2")
p2:setPosition(Vec3(0,-250,0))
p2:getScriptComponent():setUpdateFunction("p2_update")
p2.score = 0

--ball
ball = createBall()
ball:getScriptComponent():setUpdateFunction("ball_update")

--borders
createBorder()
