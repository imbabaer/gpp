
print("Initializing from lua...")

--Scripting:registerScript("asteroids_update.lua")
--Scripting:registerScript("asteroids_initialize.lua")

Scripting:registerScript("platformer_update.lua")
Scripting:registerScript("platformer_initialize.lua")


print("Finished initializing from lua.")
